# Ansible Collection - hsbc_china.finance

Documentation for the collection.
